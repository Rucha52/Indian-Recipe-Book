﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using MyRecipeBook.V2.UI;
using MyRecipeBook.V2.UI.Windows;

namespace MyRecipeBook.V2.App
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            new WindowMain().ShowDialog();
        }
    }
}
