﻿using System;
using System.Windows.Threading;

namespace MyRecipeBook.V2.UI.UserControls
{
    /// <summary>
    /// Interaction logic for DateView.xaml
    /// </summary>
    public partial class DateView
    {
        private readonly DispatcherTimer _dt;

        public DateView()
        {
            _dt = new DispatcherTimer {Interval = new TimeSpan(0, 1, 0)};
            _dt.Tick += DtTick;

            InitializeComponent();
            DtTick(this, new EventArgs());
            _dt.Start();
        }

        void DtTick(object sender, EventArgs e)
        {
            var dt = DateTime.Now;
            var mon = new[]
                          {
                              "January",
                              "February",
                              "March",
                              "April",
                              "May",
                              "June",
                              "July",
                              "August",
                              "September",
                              "October",
                              "November",
                              "December"
                          };

            var s = String.Format("{0}, {1} {2}", dt.DayOfWeek, mon[dt.Month - 1], dt.Day);
            textBlockDate.Text = s;
        }
    }
}