﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyRecipeBook.V2.ClassLib.Data;
using MyRecipeBook.V2.ClassLib.Data.MyRecipeBook_DataSetTableAdapters;

namespace MyRecipeBook.V2.ClassLib
{
    public class Meals
    {
        public List<Meal> GetMeals()
        {
            var list = new List<Meal>();
            var mdta = new MealDefinitionTableAdapter();
            var mdt = new MyRecipeBook_DataSet.MealDefinitionDataTable();

            try
            {
                mdta.Fill(mdt);

                foreach (var o in mdt)
                    list.Add(new Meal { Id = Convert.ToInt32(o["Id"].ToString()), Name = o["Name"].ToString() });
            }
            catch
            {

            }

            return list;
        }

        public List<Meal> GetMealByName(string name)
        {
            var list = new List<Meal>();
            var mdta = new MealDefinitionTableAdapter();
            var mdt = new MyRecipeBook_DataSet.MealDefinitionDataTable();

            try
            {
                mdta.FillByName(mdt, name);

                foreach (var o in mdt)
                    list.Add(new Meal { Id = Convert.ToInt32(o["Id"].ToString()), Name = o["Name"].ToString() });
            }
            catch
            {

            }

            return list;
        }

        public bool InsertMeal(string name, out string status)
        {
            if (GetMealByName(name).Count > 0)
            {
                status = "Meal already exists";
                return false;
            }

            status = "";
            var b = false;
            var mdta = new MealDefinitionTableAdapter();

            try
            {

                if (mdta.Insert(name) == 1)
                {
                    status = "Successfully added";
                    b = true;
                }
            }
            catch (Exception exp)
            {
                status = exp.Message;
                b = false;
            }

            return b;
        }

        public bool UpdateMeal(int id, string name, out string status)
        {
            if (GetMealByName(name).Count != 1)
            {
                status = "Meal does not exist";
                return false;
            }

            status = "";
            var b = false;
            var cdta = new MealDefinitionTableAdapter();

            try
            {

                if (cdta.Update(name, id) == 1)
                {
                    status = "Successfully updated";
                    b = true;
                }
            }
            catch (Exception exp)
            {
                status = exp.Message;
                b = false;
            }

            return b;
        }
    }

    public class Meal
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
