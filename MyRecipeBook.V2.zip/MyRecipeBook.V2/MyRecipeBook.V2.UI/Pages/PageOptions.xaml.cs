﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyRecipeBook.V2.UI.Pages
{
    /// <summary>
    /// Interaction logic for PageOptions.xaml
    /// </summary>
    public partial class PageOptions
    {
        public PageOptions()
        {
            InitializeComponent();
            checkBoxDebug.IsChecked = Properties.Settings.Default.Debug;
        }

        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.Debug = (checkBoxDebug.IsChecked == null ? false : (bool)checkBoxDebug.IsChecked);
            Properties.Settings.Default.Save();
        }

        private void buttonCancel_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
