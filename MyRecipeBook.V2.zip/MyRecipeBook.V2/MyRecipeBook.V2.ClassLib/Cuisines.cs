﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyRecipeBook.V2.ClassLib.Data;
using MyRecipeBook.V2.ClassLib.Data.MyRecipeBook_DataSetTableAdapters;

namespace MyRecipeBook.V2.ClassLib
{
    public class Cuisines
    {
        public List<Cuisine> GetCuisines()
        {
            var list = new List<Cuisine>();
            var mdta = new CuisineDefinitionTableAdapter();
            var mdt = new MyRecipeBook_DataSet.CuisineDefinitionDataTable();

            try
            {
                mdta.Fill(mdt);

                foreach (var o in mdt)
                    list.Add(new Cuisine { Id = Convert.ToInt32(o["Id"].ToString()), Name = o["Name"].ToString() });
            }
            catch
            {

            }

            return list;
        }

        public List<Cuisine> GetCuisineByName(string name)
        {
            var list = new List<Cuisine>();
            var mdta = new CuisineDefinitionTableAdapter();
            var mdt = new MyRecipeBook_DataSet.CuisineDefinitionDataTable();

            try
            {
                mdta.FillByName(mdt, name);

                foreach (var o in mdt)
                    list.Add(new Cuisine { Id = Convert.ToInt32(o["Id"].ToString()), Name = o["Name"].ToString() });
            }
            catch
            {

            }

            return list;
        }

        public bool InsertCuisine(string name, out string status)
        {
            if (GetCuisineByName(name).Count > 0)
            {
                status = "Cuisine already exists";
                return false;
            }

            status = "";
            var b = false;
            var mdta = new CuisineDefinitionTableAdapter();

            try
            {

                if (mdta.Insert(name) == 1)
                {
                    status = "Successfully added";
                    b = true;
                }
            }
            catch (Exception exp)
            {
                status = exp.Message;
                b = false;
            }

            return b;
        }

        public bool UpdateCuisine(int id, string name, out string status)
        {
            if (GetCuisineByName(name).Count != 1)
            {
                status = "Cuisine does not exist";
                return false;
            }

            status = "";
            var b = false;
            var cdta = new CuisineDefinitionTableAdapter();

            try
            {

                if (cdta.Update(name, id) == 1)
                {
                    status = "Successfully updated";
                    b = true;
                }
            }
            catch (Exception exp)
            {
                status = exp.Message;
                b = false;
            }

            return b;
        }
    }

    public class Cuisine
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
