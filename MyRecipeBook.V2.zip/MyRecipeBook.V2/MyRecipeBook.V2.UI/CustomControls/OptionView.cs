﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyRecipeBook.V2.UI.CustomControls
{
    public class OptionView : Control
    {
        public static readonly DependencyProperty CaptionProperty =
            DependencyProperty.Register("Caption", typeof (String), typeof (OptionView),
                                        new PropertyMetadata("OptionView"));

        public string Caption
        {
            get { return (String) GetValue(CaptionProperty); }
            set { SetValue(CaptionProperty, value); }
        }

        static OptionView()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(OptionView), new FrameworkPropertyMetadata(typeof(OptionView)));
            
        }
    }
}
