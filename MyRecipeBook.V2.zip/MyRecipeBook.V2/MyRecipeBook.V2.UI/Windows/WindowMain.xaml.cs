﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyRecipeBook.V2.UI.CustomControls;

namespace MyRecipeBook.V2.UI.Windows
{
	/// <summary>
	/// Interaction logic for WindowMain.xaml
	/// </summary>
	public partial class WindowMain : Window
	{

		public WindowMain()
		{
			InitializeComponent();
			
			// Insert code required on object creation below this point.
            Properties.Settings.Default.PropertyChanged += DefaultPropertyChanged;
            optionViewDebug.Visibility = Properties.Settings.Default.Debug ? Visibility.Visible : Visibility.Collapsed;
		}

        void DefaultPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Debug")
            {
                optionViewDebug.Visibility = Properties.Settings.Default.Debug ? Visibility.Visible : Visibility.Collapsed;
            }
        }

	    private void OptionView_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
		    var o = sender as OptionView;
		    if (o == null) return;

		    var s = o.Caption;
		    var u = "../Pages/Page" + s + ".xaml";
		    framePage.Source = new Uri(u, UriKind.RelativeOrAbsolute);
		}

        private void optionViewExit_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Close();
        }
	}
}