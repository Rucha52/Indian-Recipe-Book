﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyRecipeBook.V2.ClassLib.Data;
using MyRecipeBook.V2.ClassLib.Data.MyRecipeBook_DataSetTableAdapters;

namespace MyRecipeBook.V2.ClassLib
{
    public class Courses
    {
        public List<Course> GetCourses()
        {
            var list = new List<Course>();
            var mdta = new CourseDefinitionTableAdapter();
            var mdt = new MyRecipeBook_DataSet.CourseDefinitionDataTable();

            try
            {
                mdta.Fill(mdt);

                foreach (var o in mdt)
                    list.Add(new Course { Id = Convert.ToInt32(o["Id"].ToString()), Name = o["Name"].ToString() });
            }
            catch
            {

            }

            return list;
        }

        public List<Course> GetCourseByName(string name)
        {
            var list = new List<Course>();
            var mdta = new CourseDefinitionTableAdapter();
            var mdt = new MyRecipeBook_DataSet.CourseDefinitionDataTable();

            try
            {
                mdta.FillByName(mdt, name);

                foreach (var o in mdt)
                    list.Add(new Course { Id = Convert.ToInt32(o["Id"].ToString()), Name = o["Name"].ToString() });
            }
            catch
            {

            }

            return list;
        }

        public bool InsertCourse(string name, out string status)
        {
            if (GetCourseByName(name).Count > 0)
            {
                status = "Course already exists";
                return false;
            }

            status = "";
            var b = false;
            var mdta = new CourseDefinitionTableAdapter();

            try
            {

                if (mdta.Insert(name) == 1)
                {
                    status = "Successfully added";
                    b = true;
                }
            }
            catch (Exception exp)
            {
                status = exp.Message;
                b = false;
            }

            return b;
        }

        public bool UpdateCourse(int id, string name, out string status)
        {
            if (GetCourseByName(name).Count != 1)
            {
                status = "Course does not exist";
                return false;
            }

            status = "";
            var b = false;
            var cdta = new CourseDefinitionTableAdapter();

            try
            {

                if (cdta.Update(name, id) == 1)
                {
                    status = "Successfully updated";
                    b = true;
                }
            }
            catch (Exception exp)
            {
                status = exp.Message;
                b = false;
            }

            return b;
        }
    }

    public class Course
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
