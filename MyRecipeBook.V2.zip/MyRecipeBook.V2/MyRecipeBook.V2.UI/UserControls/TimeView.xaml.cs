﻿using System;
using System.Windows.Threading;

namespace MyRecipeBook.V2.UI.UserControls
{
    /// <summary>
    /// Interaction logic for TimeView.xaml
    /// </summary>
    public partial class TimeView
    {
        private readonly DispatcherTimer _dt;

        public TimeView()
        {
            _dt = new DispatcherTimer {Interval = new TimeSpan(0, 0, 1)};
            _dt.Tick += DtTick;

            InitializeComponent();
            DtTick(this, new EventArgs());
            _dt.Start();
        }

        void DtTick(object sender, EventArgs e)
        {
            var dt = DateTime.Now;
            var s = dt.ToShortTimeString().ToLower();
            //var s = String.Format("{0}:{1:00} {2}", dt.Hour, dt.Minute, (dt.Hour < 12 ? "am" : "pm"));
            textBlockTime.Text = s;
        }
    }
}