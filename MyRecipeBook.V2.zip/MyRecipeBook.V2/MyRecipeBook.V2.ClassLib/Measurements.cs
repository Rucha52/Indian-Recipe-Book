﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyRecipeBook.V2.ClassLib.Data;
using MyRecipeBook.V2.ClassLib.Data.MyRecipeBook_DataSetTableAdapters;

namespace MyRecipeBook.V2.ClassLib
{
    public class Measurements
    {
        public List<Measurement> GetMeasurements()
        {
            var list = new List<Measurement>();
            var mdta = new MeasurementDefinitionTableAdapter();
            var mdt = new MyRecipeBook_DataSet.MeasurementDefinitionDataTable();

            try
            {
                mdta.Fill(mdt);

                foreach (var o in mdt)
                    list.Add(new Measurement {Id = Convert.ToInt32(o["Id"].ToString()), Name = o["Name"].ToString()});
            }
            catch
            {
                
            }

            return list;
        }

        public List<Measurement> GetMeasurementByName(string name)
        {
            var list = new List<Measurement>();
            var mdta = new MeasurementDefinitionTableAdapter();
            var mdt = new MyRecipeBook_DataSet.MeasurementDefinitionDataTable();

            try
            {
                mdta.FillByName(mdt, name);

                foreach (var o in mdt)
                    list.Add(new Measurement { Id = Convert.ToInt32(o["Id"].ToString()), Name = o["Name"].ToString() });
            }
            catch
            {

            }

            return list;
        }

        public bool InsertMeasurement(string name, out string status)
        {
            if (GetMeasurementByName(name).Count > 0)
            {
                status = "Measurement already exists";
                return false;
            }

            status = "";
            var b = false;
            var mdta = new MeasurementDefinitionTableAdapter();

            try
            {

                if (mdta.Insert(name, string.Empty) == 1)
                {
                    status = "Successfully added";
                    b = true;
                }
            }
            catch (Exception exp)
            {
                status = exp.Message;
                b = false;
            }

            return b;
        }

        public bool UpdateMeasurement(int id, string name, out string status)
        {
            if (GetMeasurementByName(name).Count != 1)
            {
                status = "Measurement does not exist";
                return false;
            }

            status = "";
            var b = false;
            var mdta = new MeasurementDefinitionTableAdapter();

            try
            {

                if (mdta.Update(name, string.Empty, id)  == 1)
                {
                    status = "Successfully updated";
                    b = true;
                }
            }
            catch (Exception exp)
            {
                status = exp.Message;
                b = false;
            }

            return b;
        }
    }

    public class Measurement
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
