﻿using System.Windows.Controls;
using MyRecipeBook.V2.ClassLib;

namespace MyRecipeBook.V2.UI.Pages
{
    /// <summary>
    /// Interaction logic for PageDefinitions.xaml
    /// </summary>
    public partial class PageDefinitions : Page
    {
        public PageDefinitions()
        {
            var listMeasurement = new Measurements().GetMeasurements();
            var listCourses = new Courses().GetCourses();
            var listCuisines = new Cuisines().GetCuisines();
            var listMeals = new Meals().GetMeals();

            InitializeComponent();

            listBoxMeasurements.ItemsSource = listMeasurement;
            listBoxCourses.ItemsSource = listCourses;
            listBoxCuisines.ItemsSource = listCuisines;
            listBoxMeals.ItemsSource = listMeals;
        }
    }
}
